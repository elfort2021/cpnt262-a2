# cpnt262-a2 - Dynamic Image Gallery
## Author: Eleanor Forte, 000841873


**Shout Outs** 
- Swapna, for helping me find the one error in my h2 that was ruining everything and making me want to cry and eat cupcakes.
- Cry Club: Erica, Kyle and Karen for small errors and general buffonery. Love em. 

### Github Links: 
- Repo: https://github.com/elfort2021/cpnt262-a2
- Pages: 


## Attributions: 
- Photo by Filip Kominik (Doorways)
https://unsplash.com/photos/IHtVbLRjTZU

- Photo by Ren Ran on Unsplash (watermelon leaves)
https://unsplash.com/photos/bBiuSdck8tU

- Photo by Kendal on Unsplash (fiddle leaf)
https://unsplash.com/photos/TW2bfT_tWDI

- Photo by Elsa Noblet on Unsplash (Greenhouse)
https://unsplash.com/photos/r37oKn9cW-s

- Photo by Paula Russell (Monstera Leaf)
https://unsplash.com/photos/8FSJjOb1nUc

- Photo by Gerome Brunaeu (Sunflowers)
https://unsplash.com/photos/RPmWEtZLh7U

- Photo by Annie Sprat (Succulents in Pots)
https://unsplash.com/photos/ncQ2sguVlgo

- Photo by Olena Sergienko (Fern Leaf)
https://unsplash.com/photos/r0M9HrfJMBM

- Photo by Scott Webb (Rubber Tree)
https://unsplash.com/photos/BLBCj6dxaSE
